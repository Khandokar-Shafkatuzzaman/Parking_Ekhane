package com.hridoy;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.firebase.geofire.GeoQuery;
import com.firebase.geofire.GeoQueryEventListener;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hridoy.parking_ekhane.R;
import com.hridoy.parking_ekhane.SettingsActivity;
import com.hridoy.parking_ekhane.WelcomeActivity;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class OwnerMapActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {

    private GoogleMap mMap;
    GoogleApiClient googleApiClient;
    Location LastLocation;
    LocationRequest locationRequest;

    private Button OwnerLogoutButton;
    private Button OwnerSettingsButton;
    private Button SeekerSelectButton;
    private String OwnerID;
    private LatLng SeekerSelectedLocation;
    private int radius = 1;
    private Boolean SeekerFound = false, requestType = false;
    private String SeekerFoundID;
    Marker DriverMarker, PickUpMarker;

    GeoQuery geoQuery;
    private ValueEventListener SeekerLocationRefListner;


    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private DatabaseReference OwnerDatabaseRef;
    private DatabaseReference SeekerAvailableRef;
    private DatabaseReference SeekerRef;
    private DatabaseReference SeekerLocationRef;

    private TextView txtName, txtPhone;
    private CircleImageView profilePic;
    private RelativeLayout relativeLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_map);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        OwnerID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        OwnerDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Owner Selection");
        SeekerAvailableRef = FirebaseDatabase.getInstance().getReference().child("These people are seeking");
        SeekerLocationRef = FirebaseDatabase.getInstance().getReference().child("Seeker got parking location");

        OwnerLogoutButton = (Button) findViewById(R.id.owner_logout_button);
        SeekerSelectButton = (Button) findViewById(R.id.seeker_call_button);
        OwnerSettingsButton = (Button) findViewById(R.id.owner_settings_button);

        txtName = findViewById(R.id.name_seeker);
        txtPhone = findViewById(R.id.phone_seeker);
        profilePic = findViewById(R.id.profile_image_seeker);
        relativeLayout = findViewById(R.id.rel1);


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        OwnerSettingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(OwnerMapActivity.this, SettingsActivity.class);
                intent.putExtra("type", "Seekers");
                startActivity(intent);
            }
        });

        OwnerLogoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mAuth.signOut();
                LogOutOwner();
            }
        });
        SeekerSelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (requestType){
                    requestType = false;
                    geoQuery.removeAllListeners();
                    SeekerLocationRef.removeEventListener(SeekerLocationRefListner);

                    if (SeekerFound != null){
                        SeekerRef = FirebaseDatabase.getInstance().getReference().child("Users")
                                .child("Seekers").child(SeekerFoundID).child("SeekerParkingID");
                        SeekerRef.removeValue();

                        SeekerFoundID = null;
                    }
                    SeekerFound = false;
                    radius = 1;
                    String ownerID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    GeoFire geoFire = new GeoFire(OwnerDatabaseRef);
                    geoFire.removeLocation(ownerID);
                    if( PickUpMarker != null){
                        PickUpMarker.remove();
                    }
                    SeekerSelectButton.setText("Get A Parking Location");

                    relativeLayout.setVisibility(View.GONE);

                }else {
                    requestType = true;
                    String ownerID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    GeoFire geoFire = new GeoFire(OwnerDatabaseRef);
                    geoFire.setLocation(OwnerID, new GeoLocation(LastLocation.getLatitude(),LastLocation.getLongitude()));

                    SeekerSelectedLocation = new LatLng(LastLocation.getLatitude(),LastLocation.getLongitude());
                    mMap.addMarker(new MarkerOptions().position(SeekerSelectedLocation).title("My Location"));

                    SeekerSelectButton.setText("Getting your parking Location");

                    SelectClosestSeeker();
                }




            }
        });
    }

    private void SelectClosestSeeker() {

        GeoFire geoFire = new GeoFire(SeekerAvailableRef);
        GeoQuery geoQuery = geoFire.queryAtLocation(new GeoLocation(SeekerSelectedLocation.latitude, SeekerSelectedLocation.longitude), radius);
        geoQuery.removeAllListeners();

        geoQuery.addGeoQueryEventListener(new GeoQueryEventListener() {
            @Override
            public void onKeyEntered(String key, GeoLocation location) {

                if (!SeekerFound && requestType) {
                    SeekerFound = true;
                    SeekerFoundID = key;

                    SeekerRef = FirebaseDatabase.getInstance().getReference().child("Users").child("Seekers").child(SeekerFoundID);
                    HashMap<String, Object> seekerMap = new HashMap<>();
                    seekerMap.put("SeekerParkingID", OwnerID);
                    SeekerRef.updateChildren(seekerMap);

                    GettingSeekerLocation();
                    SeekerSelectButton.setText("Looking for Parking Location");
                }
            }



            @Override
            public void onKeyExited(String key) {

            }

            @Override
            public void onKeyMoved(String key, GeoLocation location) {

            }

            @Override
            public void onGeoQueryReady() {
                if (!SeekerFound) {
                    radius = radius + 1;
                    SelectClosestSeeker();

                }

            }

            @Override
            public void onGeoQueryError(DatabaseError error) {

            }
        });

    }
    private void GettingSeekerLocation() {

        SeekerLocationRefListner = SeekerLocationRef.child(SeekerFoundID).child("l")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        if (dataSnapshot.exists() && requestType) {

                            List<Object> seekerLocationMap = (List<Object>) dataSnapshot.getValue();
                            double locationLat = 0;
                            double locationLng = 0;
                            SeekerSelectButton.setText("Parking Location Found");

                            relativeLayout.setVisibility(View.VISIBLE);
                            getAssignedSeekerInformation();

                            if (seekerLocationMap.get(0) != null) {

                                locationLat = Double.parseDouble(seekerLocationMap.get(0).toString());

                            }
                            if (seekerLocationMap.get(1) != null) {

                                locationLng = Double.parseDouble(seekerLocationMap.get(1).toString());

                            }

                            LatLng SeekerLatlng = new LatLng(locationLat, locationLng);
                            if (DriverMarker != null) {
                                DriverMarker.remove();
                            }

                            Location location1 = new Location("");
                            location1.setLatitude(SeekerSelectedLocation.latitude);
                            location1.setLongitude(SeekerSelectedLocation.longitude);

                            Location location2 = new Location("");
                            location2.setLatitude(SeekerLatlng.latitude);
                            location2.setLongitude(SeekerLatlng.longitude);

                            float Distance = location1.distanceTo(location2);

                            if (Distance < 90){
                                SeekerSelectButton.setText("Location Reached");
                            }else{

                                SeekerSelectButton.setText("Parking Location: " + Distance + " meters");

                            }



                            DriverMarker = mMap.addMarker(new MarkerOptions().position(SeekerLatlng).title("Parking Location is here").icon(BitmapDescriptorFactory.fromResource(R.drawable.parking)));

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

    }


    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        buildGoogleApiClient();
        mMap.setMyLocationEnabled(true);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(locationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        LastLocation = location;
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
        mMap.animateCamera(CameraUpdateFactory.zoomTo(14));

    }

    protected synchronized void buildGoogleApiClient() {
        googleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        googleApiClient.connect();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    private void LogOutOwner() {
        Intent welcomeIntent = new Intent(OwnerMapActivity.this, WelcomeActivity.class);
        welcomeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(welcomeIntent);
        finish();
    }

    private void getAssignedSeekerInformation() {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Users").child("Owners").child(SeekerFoundID);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() && dataSnapshot.getChildrenCount() > 0) {

                    String name = dataSnapshot.child("name").getValue().toString();
                    String phone = dataSnapshot.child("phone").getValue().toString();

                    txtName.setText(name);
                    txtPhone.setText(phone);

                    if (dataSnapshot.hasChild("image")) {
                        String image = dataSnapshot.child("image").getValue().toString();
                        Picasso.get().load(image).into(profilePic);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
