package com.hridoy.parking_ekhane;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.os.Handler;
import android.os.PersistableBundle;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hridoy.OwnerMapActivity;
import com.squareup.picasso.Picasso;

import java.util.List;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;

public class SeekerMapActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        com.google.android.gms.location.LocationListener {



    private GoogleMap mMap;
    GoogleApiClient googleApiClient;
    Location lastLocation;
    LocationRequest locationRequest;
    private Button SeekerSettingButton;
    private Button SeekerLogoutButton;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;
    private boolean currentLogoutSeekerStatus= false;
    private DatabaseReference assignedOwnerRef, assignedOwnerSelectionRef;
    private String seekerID, ownerID="";
    private TextView txtName,txtPhone,txtCarName;
    private CircleImageView profilePic;
    private RelativeLayout relativeLayout;
    Marker pickUpMarker;
    private  ValueEventListener AssignedOwnerPickUpRefListener;
    Chronometer chronometer;
    ImageButton btStart,btStop;
    private boolean isResume;
    Handler handler;
    long tMilliSec,tStart,tBuff,tUpdate = 0L;
    int sec, min, milliSec;
    TextView amount_View;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeker_map);

        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();
        seekerID = mAuth.getCurrentUser().getUid();

        SeekerLogoutButton = (Button) findViewById(R.id.seeker_logout_button);
        SeekerSettingButton = (Button) findViewById(R.id.seeker_settings_button);
        txtName = findViewById(R.id.name_owner);
        txtPhone = findViewById(R.id.phone_owner);
        txtCarName = findViewById(R.id.car_name_owner);
        profilePic = findViewById(R.id.profile_image_owner);
        relativeLayout = findViewById(R.id.rel2);
        chronometer = findViewById(R.id.chronometer);
        btStart = findViewById(R.id.startButton);
        btStop = findViewById(R.id.stopButton);
        amount_View = findViewById(R.id.amount_view);
        handler = new Handler();
        btStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!isResume){
                    tStart = SystemClock.uptimeMillis();
                    handler.postDelayed(runnable,0);
                    chronometer.start();
                    isResume = true;
                    btStop.setVisibility(View.GONE);
                    btStart.setImageDrawable(getResources().getDrawable(R.drawable.ic_pause));

                }else{
                    tBuff += tMilliSec;
                    handler.removeCallbacks(runnable);
                    chronometer.stop();
                    isResume = false;
                    btStop.setVisibility(View.VISIBLE);
                    btStart.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));

                }
            }
        });
        btStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isResume){
                    btStart.setImageDrawable(getResources().getDrawable(R.drawable.ic_play));
                    setAmount_View();
                    tMilliSec = 0L;
                    tStart = 0L;
                    tBuff = 0L;
                    tUpdate = 0L;
                    sec = 0;
                    min = 0;
                    milliSec = 0;
                    chronometer.setText("00:00:00");
                }
            }
        });




        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        SeekerSettingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SeekerMapActivity.this, SettingsActivity.class);
                intent.putExtra("type","Owners");
                startActivity(intent);
            }
        });

        SeekerLogoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentLogoutSeekerStatus=true;
                DisconnectTheSeeker();

                mAuth.signOut();
                LogOutSeeker();

            }
        });
        GetAssignedOwnerRequest();
    }
    private void setAmount_View(){

        double amount = 5 + (min * 0.5);
        amount_View.setText("TK: "+(int) amount);
    }

    private void GetAssignedOwnerRequest() {

        assignedOwnerRef = FirebaseDatabase.getInstance().getReference().child("Users")
                .child("Seekers").child(seekerID).child("SeekerParkingID");

        assignedOwnerRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){

                    ownerID = Objects.requireNonNull(dataSnapshot.getValue()).toString();

                    GetAcceptedOwnerLocation();

                    relativeLayout.setVisibility(View.VISIBLE);
                    getAssignedOwnerInformation();
                }
                else {
                    ownerID= "";
                    if (pickUpMarker != null){
                        pickUpMarker.remove();
                    }
                    if (AssignedOwnerPickUpRefListener != null){
                        assignedOwnerSelectionRef.removeEventListener(AssignedOwnerPickUpRefListener);
                    }
                    relativeLayout.setVisibility(View.GONE);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private Runnable runnable = new Runnable() {
        @Override
        public void run() {
            tMilliSec = SystemClock.uptimeMillis() - tStart;
            tUpdate = tBuff + tMilliSec;
            sec = (int)(tUpdate/1000);
            min = sec/60;
            sec = sec%60;
            milliSec = (int)(tUpdate%100);
            chronometer.setText(String.format("%02d", min)+":"+
                    String.format("%02d",sec)+":"+String.format("%02d",milliSec));
            handler.postDelayed(this,60);

        }
    };

    private void GetAcceptedOwnerLocation() {

        assignedOwnerSelectionRef = FirebaseDatabase.getInstance().getReference().child("Owner Selection")
                .child(ownerID).child("l");

        AssignedOwnerPickUpRefListener = assignedOwnerSelectionRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()){

                    List <Object> ownerLocationMap = (List <Object>) dataSnapshot.getValue();

                    double locationLat = 0;
                    double locationLng = 0;

                    if(ownerLocationMap.get(0)!= null){
                        locationLat = Double.parseDouble(ownerLocationMap.get(0).toString());

                    }
                    if(ownerLocationMap.get(1)!= null){
                        locationLng = Double.parseDouble(ownerLocationMap.get(1).toString());
                    }
                    LatLng SeekerLatlng = new LatLng(locationLat,locationLng);
                    pickUpMarker = mMap.addMarker(new MarkerOptions().position(SeekerLatlng).title("Seeker Current Location").icon(BitmapDescriptorFactory.fromResource(R.drawable.car)));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        buildGoogleApiClient();
        mMap.setMyLocationEnabled(true);

    }
    public void onCreate(@Nullable Bundle savedInstanceState, @Nullable PersistableBundle persistentState)
    {
        super.onCreate(savedInstanceState, persistentState);


    }
    public void onLocationChanged(Location location) {

        if (getApplicationContext() != null){

            lastLocation = location;
            LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
            mMap.moveCamera(CameraUpdateFactory.newLatLng(latLng));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(13));

            String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();


            DatabaseReference seekerAvailabilityRef = FirebaseDatabase.getInstance().getReference().child("These people are seeking");
            GeoFire geoFireAvailability = new GeoFire(seekerAvailabilityRef);

            DatabaseReference SeekerRidingRef = FirebaseDatabase.getInstance().getReference().child("Seeker got parking location");
            GeoFire geoFireSelected = new GeoFire(SeekerRidingRef);




            switch (ownerID){

                case "":
                    geoFireSelected.removeLocation(userID);
                    geoFireAvailability.setLocation(userID, new GeoLocation(location.getLatitude(),location.getLongitude()));
                    break;

                default:
                    geoFireAvailability.removeLocation(userID);
                    geoFireSelected.setLocation(userID, new GeoLocation(location.getLatitude(),location.getLongitude()));
                    break;
            }
        }

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1000);
        locationRequest.setFastestInterval(1000);
        locationRequest.setPriority(locationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);


    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    protected synchronized void buildGoogleApiClient(){
        googleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
        googleApiClient.connect();
    }


    @Override
    protected void onStop() {
        super.onStop();

        if (!currentLogoutSeekerStatus){
           DisconnectTheSeeker();
        }
    }
    private void DisconnectTheSeeker() {
        String userID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        DatabaseReference SeekerAvailabilityRef = FirebaseDatabase.getInstance().getReference().child("These people are seeking");
        GeoFire geoFire = new GeoFire(SeekerAvailabilityRef);
        geoFire.removeLocation(userID);
        LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient,this);
    }

    private void LogOutSeeker() {
        Intent welcomeIntent = new Intent(SeekerMapActivity.this, WelcomeActivity.class);
        welcomeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(welcomeIntent);
        finish();
    }
    private void getAssignedOwnerInformation()
    {
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Users").child("Seekers").child(ownerID);

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists() && dataSnapshot.getChildrenCount() > 0){

                    String name = dataSnapshot.child("name").getValue().toString();
                    String phone = dataSnapshot.child("phone").getValue().toString();
                    String car = dataSnapshot.child("car_model").getValue().toString();

                    txtName.setText(name);
                    txtPhone.setText(phone);
                    txtCarName.setText(car);

                    if (dataSnapshot.hasChild("image"))
                    {
                        String image = dataSnapshot.child("image").getValue().toString();
                        Picasso.get().load(image).into(profilePic);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



}

