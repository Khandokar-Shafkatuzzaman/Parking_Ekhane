package com.hridoy.parking_ekhane;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hridoy.OwnerMapActivity;

import org.w3c.dom.Text;

public class OwnerLoginRegisterActivity extends AppCompatActivity {

    private Button OwnerLoginButton;
    private Button OwnerRegisterButton;
    private TextView OwnerRegisterLink;
    private TextView OwnerStatus;
    private EditText EmailOwner;
    private EditText PasswordOwner;
    private ProgressDialog loadingBar;
    private FirebaseAuth mAuth;
    private DatabaseReference OwnerDatabaseRef;
    private String onlineOwnerID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_owner_login_register);

        mAuth = FirebaseAuth.getInstance();

        OwnerLoginButton = findViewById(R.id.owner_login_button);
        OwnerRegisterButton = findViewById(R.id.owner_register_button);
        OwnerRegisterLink = findViewById(R.id.register_owner_link);
        OwnerStatus = findViewById(R.id.owner_status);
        EmailOwner = findViewById(R.id.email_owner);
        PasswordOwner =  findViewById(R.id.password_owner);
        loadingBar = new ProgressDialog(this);

        OwnerRegisterButton.setVisibility(View.INVISIBLE);
        OwnerRegisterButton.setEnabled(false);

        OwnerRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                OwnerLoginButton.setVisibility(View.INVISIBLE);
                OwnerRegisterLink.setVisibility(View.INVISIBLE);
                OwnerStatus.setText("Parking Seeker Register");
                OwnerRegisterButton.setVisibility(View.VISIBLE);
                OwnerRegisterButton.setEnabled(true);
            }
        });
        OwnerRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = EmailOwner.getText().toString();
                String password = PasswordOwner.getText().toString();
                RegisterOwner(email,password);
            }
        });
        OwnerLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = EmailOwner.getText().toString();
                String password = PasswordOwner.getText().toString();
                SignInOwner(email,password);
            }
        });
    }

    private void SignInOwner(String email, String password) {

        if (TextUtils.isEmpty(email))
        {
            Toast.makeText(OwnerLoginRegisterActivity.this,"Please insert email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(OwnerLoginRegisterActivity.this,"Please insert password", Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingBar.setTitle("Seeker Login");
            loadingBar.setMessage("Please wait, while we are checking your credentials...");
            loadingBar.show();
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful())
                            {

                                Intent owner_intent = new Intent(OwnerLoginRegisterActivity.this, OwnerMapActivity.class);
                                startActivity(owner_intent);

                                Toast.makeText(OwnerLoginRegisterActivity.this,"Seeker Login Successful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                            else
                            {
                                Toast.makeText(OwnerLoginRegisterActivity.this,"Owner Login Unsuccessful, please try again.",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }

    }

    private void RegisterOwner(String email, String password) {
        if (TextUtils.isEmpty(email))
        {
            Toast.makeText(OwnerLoginRegisterActivity.this,"Please insert email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(OwnerLoginRegisterActivity.this,"Please insert password", Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingBar.setTitle("Seeker Registration");
            loadingBar.setMessage("Please wait, while we are registering your data...");
            loadingBar.show();
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful())
                            {
                                onlineOwnerID = mAuth.getCurrentUser().getUid();
                                OwnerDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Users").child("Owners").child(onlineOwnerID);
                                OwnerDatabaseRef.setValue(true);
                                Intent intent = new Intent(OwnerLoginRegisterActivity.this, OwnerMapActivity.class);
                                startActivity(intent);

                                Toast.makeText(OwnerLoginRegisterActivity.this,"Seeker Register Successful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();

                            }
                            else
                            {
                                Toast.makeText(OwnerLoginRegisterActivity.this,"Seeker Register Unsuccessful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }
    }
}
