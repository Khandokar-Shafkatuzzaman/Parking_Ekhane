package com.hridoy.parking_ekhane;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SeekerLoginRegisterAcitivity extends AppCompatActivity {

    private Button SeekerLoginButton;
    private Button SeekerRegisterButton;
    private TextView SeekerRegisterLink;
    private TextView SeekerStatus;
    private EditText EmailSeeker;
    private EditText PasswordSeeker;
    private ProgressDialog loadingBar;
    private FirebaseAuth mAuth;
    private DatabaseReference SeekerDatabaseRef;
    private String onlineSeekerID;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seeker_login_register_acitivity);
        mAuth = FirebaseAuth.getInstance();

        SeekerLoginButton = findViewById(R.id.seeker_login_button);
        SeekerRegisterButton = findViewById(R.id.seeker_register_button);
        SeekerRegisterLink = findViewById(R.id.register_seeker_link);
        SeekerStatus = findViewById(R.id.seeker_status);
        EmailSeeker = findViewById(R.id.email_seeker);
        PasswordSeeker = findViewById(R.id.password_seeker);
        loadingBar = new ProgressDialog(this);

        SeekerRegisterButton.setVisibility(View.INVISIBLE);
        SeekerRegisterButton.setEnabled(false);

        SeekerRegisterLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SeekerLoginButton.setVisibility(View.INVISIBLE);
                SeekerRegisterLink.setVisibility(View.INVISIBLE);
                SeekerStatus.setText("Parking Owner Register");
                SeekerRegisterButton.setVisibility(View.VISIBLE);
                SeekerRegisterButton.setEnabled(true);
            }
        });
        SeekerRegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = EmailSeeker.getText().toString();
                String password = PasswordSeeker.getText().toString();
                RegisterSeeker(email,password);
            }
        });
        SeekerLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = EmailSeeker.getText().toString();
                String password = PasswordSeeker.getText().toString();
                SignInSeeker(email,password);
            }
        });

    }

    private void SignInSeeker(String email, String password) {
        if (TextUtils.isEmpty(email))
        {
            Toast.makeText(SeekerLoginRegisterAcitivity.this,"Please insert email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(SeekerLoginRegisterAcitivity.this,"Please insert password", Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingBar.setTitle("Owner Login");
            loadingBar.setMessage("Please wait, while we are checking your credentials...");
            loadingBar.show();
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful())
                            {
                                Intent seeker_intent = new Intent(SeekerLoginRegisterAcitivity.this, SeekerMapActivity.class);
                                startActivity(seeker_intent);

                                Toast.makeText(SeekerLoginRegisterAcitivity.this,"Owner Login Successful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                            else
                            {
                                Toast.makeText(SeekerLoginRegisterAcitivity.this,"Owner Login Unsuccessful, please try again.",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }
    }

    private void RegisterSeeker(String email, String password) {
        if (TextUtils.isEmpty(email))
        {
            Toast.makeText(SeekerLoginRegisterAcitivity.this,"Please insert email", Toast.LENGTH_SHORT).show();
        }
        if (TextUtils.isEmpty(password))
        {
            Toast.makeText(SeekerLoginRegisterAcitivity.this,"Please insert password", Toast.LENGTH_SHORT).show();
        }
        else
        {
            loadingBar.setTitle("Owner Registration");
            loadingBar.setMessage("Please wait, while we are registering your data...");
            loadingBar.show();
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {

                            if(task.isSuccessful())
                            {
                                onlineSeekerID = mAuth.getCurrentUser().getUid();
                                SeekerDatabaseRef = FirebaseDatabase.getInstance().getReference().child("Users").child("Seekers").child(onlineSeekerID);
                                SeekerDatabaseRef.setValue(true);
                                Intent seeker_intent = new Intent(SeekerLoginRegisterAcitivity.this, SeekerMapActivity.class);
                                startActivity(seeker_intent);
                                Toast.makeText(SeekerLoginRegisterAcitivity.this,"Owner Register Successful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                            else
                            {
                                Toast.makeText(SeekerLoginRegisterAcitivity.this,"Owner Register Unsuccessful",Toast.LENGTH_LONG).show();
                                loadingBar.dismiss();
                            }
                        }
                    });
        }
    }
}
